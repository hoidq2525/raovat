iOS7-icon-font
==============
This is a Web-fonts of iOS7 icons.  


A webfont of iOS 7 icons, based on Free iOS 7 icons in vector. Original Github Project by AKIRA-MIYAKE.

Forked to add keywords for easier searching, and roughly sorted by category.

[Demo](http://akira-miyake.github.io/iOS7-icon-font/)

----------
Original copyright &copy; 2014 AKIRA-MIYAKE
Distributed under the [MIT License][mit].

[MIT]: http://www.opensource.org/licenses/mit-license.php
